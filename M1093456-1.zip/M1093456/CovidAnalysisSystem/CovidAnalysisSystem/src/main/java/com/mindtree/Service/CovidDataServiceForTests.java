package com.mindtree.Service;

import com.mindtree.Dao.DataBaseConnectionDao;
import com.mindtree.Exceptions.InvalidDateException;
import com.mindtree.Exceptions.InvalidDateRangeException;
import com.mindtree.Exceptions.InvalidStateCodeException;
import com.mindtree.Exceptions.NoDataFoundException;
import com.mindtree.Model.CovidData;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class CovidDataServiceForTests {//The Service class without using try and catch blocks and it is used for testing purpose.Based upon this service class and  when an exception is raised, those are thrown to the exception class  instead of handling those
    private final List<CovidData> covidData;

    public CovidDataServiceForTests(DataBaseConnectionDao dataBaseConnectionDao) throws SQLException, ClassNotFoundException {
        covidData = dataBaseConnectionDao.getAllCovidDataFromDb();
    }


    public List<String> getAllUniqueStates() {
        return covidData.stream().map(CovidData::getState).distinct().sorted().collect(Collectors.toList());
    }

    public List<String> getAllUniqueDistrictsUnderSpecificStateCode(String stateCode) throws InvalidStateCodeException {
        List<String > districts;
        if (this.covidData.stream().anyMatch(covidData->covidData.getState().equals(stateCode))) {
            Predicate<CovidData> value = covid_data -> covid_data.getState().equalsIgnoreCase(stateCode);
            districts=covidData.stream().filter(value).map(CovidData::getDistrict).distinct().sorted().collect(Collectors.toList());
        } else {
            throw new InvalidStateCodeException("Invalid State code,please check your input.");
        }
        return districts;
    }

    public ConcurrentMap<LocalDate, ConcurrentMap<String, Integer>> getStatesDataWithInDateRange(LocalDate date1, LocalDate date2) throws InvalidDateException, InvalidDateRangeException, NoDataFoundException {
        if (this.covidData.stream().noneMatch(covidData -> covidData.getDate().isEqual(date2)))
            throw new InvalidDateException("Invalid Start Date,please check your input.");
        else if (this.covidData.stream().noneMatch(covidData -> covidData.getDate().isEqual(date1)))
            throw new InvalidDateException("Invalid End Date,please check your input.");
        else if (!date1.isBefore(date2))
            throw new InvalidDateRangeException("Invalid Date Range,please check Your Input.");
        List<CovidData> collect = covidData.stream().filter(covidData -> covidData.getDate().isAfter(date1) && covidData.getDate().isBefore(date2)).toList();
        if (collect.isEmpty()) throw new NoDataFoundException("No Data Present.");
        ConcurrentMap<LocalDate, ConcurrentMap<String, Integer>> mapMap = collect.stream().collect(Collectors.groupingByConcurrent(CovidData::getDate,Collectors.groupingByConcurrent(CovidData::getState,Collectors.summingInt(CovidData::getConfirmed))));
        return new ConcurrentHashMap<>(mapMap);
    }


    public ConcurrentMap<LocalDate,ConcurrentMap<String, Integer>> getConfirmedCasesByComparingTwoStatesData(LocalDate date1, LocalDate date2, String firstStateCode, String secondStateCode) throws InvalidDateException, InvalidDateRangeException, InvalidStateCodeException, NoDataFoundException {
        if (this.covidData.stream().noneMatch(cd -> cd.getDate().isEqual(date1)))
            throw new InvalidDateException("Invalid End Date Please Check your input.");
        else if (this.covidData.stream().noneMatch(cd -> cd.getDate().isEqual(date2)))
            throw new InvalidDateException("Invalid Start Date Please Check your input.");
        else if (!date1.isBefore(date2))
            throw new InvalidDateRangeException("Invalid Date Range, check Your Input.");
        else {
            if (this.covidData.stream().noneMatch(covidData -> covidData.getState().equals(firstStateCode)))
                throw new InvalidStateCodeException("Invalid State code, please check your input");
            else if (this.covidData.stream().noneMatch(covidData -> covidData.getState().equals(secondStateCode)))
                throw new InvalidStateCodeException("Invalid State code, please check your input");
            Predicate<CovidData> datePredicate = covidData -> covidData.getDate().isAfter(date1) && covidData.getDate().isBefore(date2);
            Predicate<CovidData> statePredicate = covidData -> covidData.getState().equals(firstStateCode) || covidData.getState().equals(secondStateCode);
            if ((covidData.stream().filter(datePredicate.and(statePredicate)).toList()).isEmpty())
                throw new NoDataFoundException("No Data Present.");
            ConcurrentMap<LocalDate, ConcurrentMap<String,Integer>> data = (covidData.stream().filter(datePredicate.and(statePredicate)).toList()).stream().collect(Collectors.groupingByConcurrent(CovidData::getDate,Collectors.groupingByConcurrent(CovidData::getState,Collectors.summingInt(CovidData::getConfirmed))));
            return new ConcurrentHashMap<>(data);
              }
    }
}