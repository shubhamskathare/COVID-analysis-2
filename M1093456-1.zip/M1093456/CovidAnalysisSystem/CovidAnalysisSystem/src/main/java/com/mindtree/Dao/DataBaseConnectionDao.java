package com.mindtree.Dao;

import com.mindtree.Model.CovidData;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DataBaseConnectionDao {
    public List<CovidData> getAllCovidDataFromDb() throws SQLException, ClassNotFoundException {
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/covid_analysis", "root", "12VINAYsuji$345");
         String query="select * from covid_data";
         List<CovidData> covidData=new ArrayList<>();
         Class.forName("com.mysql.cj.jdbc.Driver");
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery(query);
        while(rs.next())
        {
            CovidData covidData1=new CovidData();
            covidData1.setId(rs.getInt("id"));
            covidData1.setDate(LocalDate.parse(rs.getDate("date").toString()));
            covidData1.setState(rs.getString("state"));
            covidData1.setDistrict(rs.getString("district"));
            covidData1.setConfirmed(rs.getInt("confirmed"));
            covidData1.setTested(rs.getInt("tested"));
            covidData1.setTested(rs.getInt("recovered"));
            covidData.add(covidData1);
        }
        st.close();
        con.close();
        return covidData;
    }

}
