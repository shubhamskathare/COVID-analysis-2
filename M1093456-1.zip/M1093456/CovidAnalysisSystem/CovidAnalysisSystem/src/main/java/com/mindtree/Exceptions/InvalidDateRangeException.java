package com.mindtree.Exceptions;

import java.io.Serial;

public class InvalidDateRangeException extends Exception{
    @Serial
    private static final long serialVersionUID=1L;
    public InvalidDateRangeException(){

    }
    public InvalidDateRangeException(String msg)
    {
        super(msg);
    }
}
