package com.mindtree.Exceptions;

import java.io.Serial;

public class InvalidDateException extends Exception{
    @Serial
    private static final long serialVersionUID=1L;
    public InvalidDateException(){

    }
    public InvalidDateException(String msg)
    {
        super(msg);
    }
}
