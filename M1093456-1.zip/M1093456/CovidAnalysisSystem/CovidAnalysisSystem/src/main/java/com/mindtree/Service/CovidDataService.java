package com.mindtree.Service;

import com.mindtree.Dao.DataBaseConnectionDao;
import com.mindtree.Exceptions.InvalidDateException;
import com.mindtree.Exceptions.InvalidDateRangeException;
import com.mindtree.Exceptions.InvalidStateCodeException;
import com.mindtree.Exceptions.NoDataFoundException;
import com.mindtree.Model.CovidData;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class CovidDataService {//This service class uses try and catch blocks for handling exceptions raised in the program
    private final List<CovidData> covidData;
    public CovidDataService(DataBaseConnectionDao dataBaseConnectionDao) throws SQLException, ClassNotFoundException {
        this.covidData = dataBaseConnectionDao.getAllCovidDataFromDb();
    }


    public List<String> getAllUniqueStates() {
      return covidData.stream().map(CovidData::getState).distinct().sorted().collect(Collectors.toList());
    }

    public List<String> getAllUniqueDistrictsUnderSpecificStateCode(String stateCode) {
      List<String> districts = null;
        try {
            if (this.covidData.stream().anyMatch(covidData->covidData.getState().equals(stateCode))) {
                Predicate<CovidData> value = covid_data -> covid_data.getState().equalsIgnoreCase(stateCode);
                districts=covidData.stream().filter(value).map(CovidData::getDistrict).distinct().sorted().collect(Collectors.toList());
            } else {
                throw new InvalidStateCodeException("Invalid State code,please check your input.");
            }
       } catch (InvalidStateCodeException e) {
            System.out.println(e.getMessage());
        }

        return districts;
    }

    public ConcurrentMap<LocalDate,ConcurrentMap<String,Integer>> getStatesDataWithInDateRange(LocalDate date1, LocalDate date2) {
       try {
            if (this.covidData.stream().noneMatch(covidData -> covidData.getDate().isEqual(date2)))
                throw new InvalidDateException("Invalid Start Date,please check your input.");
            else if (this.covidData.stream().noneMatch(covidData -> covidData.getDate().isEqual(date1)))
                throw new InvalidDateException("Invalid End Date,please check your input.");
             else if (!date1.isBefore(date2))
                throw new InvalidDateRangeException("Invalid Date Range,please check Your Input.");
        } catch(InvalidDateException | InvalidDateRangeException e) {System.out.println(e.getMessage());}
        List<CovidData> collect = covidData.stream().filter(covidData -> covidData.getDate().isAfter(date1) && covidData.getDate().isBefore(date2)).toList();
       try{
            if (collect.isEmpty()) throw new NoDataFoundException("No Data Present.");
          } catch(NoDataFoundException e) {System.out.println(e.getMessage());}
        ConcurrentMap<LocalDate, ConcurrentMap<String, Integer>> mapMap = collect.stream().collect(Collectors.groupingByConcurrent(CovidData::getDate,Collectors.groupingByConcurrent(CovidData::getState,Collectors.summingInt(CovidData::getConfirmed))));
       return new ConcurrentHashMap<>(mapMap);
    }


    public ConcurrentMap<LocalDate,ConcurrentMap<String,Integer>> getConfirmedCasesByComparingTwoStatesData(LocalDate date1, LocalDate date2, String firstStateCode, String secondStateCode) {
        try {
             if (this.covidData.stream().noneMatch(cd -> cd.getDate().isEqual(date1)))
                throw new InvalidDateException("Invalid End Date Please Check your input.");
             else if (this.covidData.stream().noneMatch(cd -> cd.getDate().isEqual(date2)))
                throw new InvalidDateException("Invalid Start Date Please Check your input.");
             else if (!date1.isBefore(date2))
                throw new InvalidDateRangeException("Invalid Date Range, check Your Input.");
             else {
                if (this.covidData.stream().noneMatch(covidData -> covidData.getState().equals(firstStateCode)))
                    throw new InvalidStateCodeException("Invalid State code, please check your input");
                 else if (this.covidData.stream().noneMatch(covidData -> covidData.getState().equals(secondStateCode)))
                    throw new InvalidStateCodeException("Invalid State code, please check your input");
                }
           } catch (InvalidDateException  | InvalidDateRangeException | InvalidStateCodeException e ) {
               System.out.println(e.getMessage());
               }
          Predicate<CovidData> datePredicate = covidData -> covidData.getDate().isAfter(date1) && covidData.getDate().isBefore(date2);
          Predicate<CovidData> statePredicate = covidData -> covidData.getState().equals(firstStateCode) || covidData.getState().equals(secondStateCode);
          try{
              if ((covidData.stream().filter(datePredicate.and(statePredicate)).toList()).isEmpty())
                  throw new NoDataFoundException("No Data Present.");
             } catch (NoDataFoundException e) {
              System.out.println(e.getMessage());
                           }
         ConcurrentMap<LocalDate,ConcurrentMap<String,Integer>> data = (covidData.stream().filter(datePredicate.and(statePredicate)).toList()).stream().collect(Collectors.groupingByConcurrent(CovidData::getDate,Collectors.groupingByConcurrent(CovidData::getState,Collectors.summingInt(CovidData::getConfirmed))));
          return new ConcurrentHashMap<>(data);
    }
}