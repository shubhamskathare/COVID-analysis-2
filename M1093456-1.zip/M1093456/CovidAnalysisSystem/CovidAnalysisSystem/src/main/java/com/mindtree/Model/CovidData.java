package com.mindtree.Model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.Hibernate;

import java.time.LocalDate;
import java.util.Objects;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Table(name = "covid_data")
public class CovidData implements Comparable<CovidData> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private LocalDate date;
    private String state;
    private String district;
    private int tested;
    private int confirmed;
    private int recovered;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        CovidData that = (CovidData) o;
        return Objects.equals(id, that.id) && Objects.equals(date, that.date) && Objects.equals(state, that.state) && Objects.equals(district, that.district) && Objects.equals(tested, that.tested) && Objects.equals(confirmed, that.confirmed) && Objects.equals(recovered, that.recovered);
    }

    @Override
    public int hashCode() {
        final int prime = 5;
        int result = 1;
        result = (prime * result + id);
        result = prime * result + ((date == null) ? 0 : date.hashCode());
        result = prime * result + ((state == null) ? 0 : state.hashCode());
        result = prime * result + ((district == null) ? 0 : district.hashCode());
        result = prime * result + tested;
        result = prime * result + confirmed;
        result = prime * result + recovered;
        return result;
    }

    @Override
    public int compareTo(CovidData o) {
        return this.district.compareTo(o.district);
    }
}