package com.mindtree.Exceptions;

import java.io.Serial;

public class NoDataFoundException extends Exception{
    @Serial
    private static final long serialVersionUID=1L;
    public NoDataFoundException(){

    }
    public NoDataFoundException(String msg)
    {
        super(msg);
    }
}
