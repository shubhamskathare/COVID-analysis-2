package com.mindtree.Exceptions;

import java.io.Serial;

public class InvalidStateCodeException extends Exception{

    @Serial
    private static final long serialVersionUID=1L;
    public InvalidStateCodeException(){

    }
    public InvalidStateCodeException(String msg)
    {
        super(msg);
    }
}
