package com.mindtree.Controller;

import com.mindtree.Dao.DataBaseConnectionDao;
import com.mindtree.Service.CovidDataService;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ConcurrentMap;

public class MainMenuController  {

 private static  final  Scanner sin = new Scanner(System.in);
 private static final DataBaseConnectionDao dataBaseConnectionDao=new DataBaseConnectionDao();
 private static final CovidDataService service;

    static {
        try {
            service = new CovidDataService(dataBaseConnectionDao);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }


    public static void main(String[] args) {

        while (true) {
            System.out.println("********************************************");
            System.out.println("1. Get State Names");
            System.out.println("2. Get District for given state");
            System.out.println("3. Display Data by State with in Date Range");
            System.out.println("4. Display Confirmed cases by comparing two states for a given date range.");
            System.out.println("5. Exit");
            System.out.println("Please select Option :");
            int n = sin.nextInt();
            switch (n) {
                case 1 -> getAllStates();
                case 2 -> getAllDistricts();
                case 3 -> displayDataByStateInDateRange();
                case 4 -> displayConfirmedcasesInDateRange();
                case 5 -> System.exit(0);
            }
        }
    }
        public static void getAllStates() {
            List<String> states=service.getAllUniqueStates();
            states.forEach(System.out::println);
        }

        public static void getAllDistricts()  {
            System.out.println("Please enter state code :");
            String statecode = sin.next();
            statecode = statecode.toUpperCase(Locale.ROOT);
            List<String> districts = service.getAllUniqueDistrictsUnderSpecificStateCode(statecode);
            if(districts==null)
                System.out.println("Please enter correct state code");
            else {
                districts.forEach(System.out::println);
                }
        }

        public static void displayDataByStateInDateRange(){
            ConcurrentMap<LocalDate,ConcurrentMap<String,Integer>>  dates;
            System.out.println("Please enter start date (yyyy-MM-dd) :");
            String date1=sin.next();
            LocalDate startDate=LocalDate.parse(date1);
            System.out.println("Please enter End date (yyyy-MM-dd) :");
            String date2=sin.next();
            LocalDate endDate=LocalDate.parse(date2);
             dates=service.getStatesDataWithInDateRange(startDate,endDate);
             System.out.println("  Date  | State  | Cofirmed total");
             for(ConcurrentMap.Entry<LocalDate,ConcurrentMap<String,Integer>> mapEntry : dates.entrySet()) {
                 mapEntry.getValue().forEach((k, v) -> System.out.println(mapEntry.getKey() + "  |   " + k + " |    " + v));
             }
        }

        public static void displayConfirmedcasesInDateRange(){
            System.out.print("Please enter start date (yyyy-MM-dd) : ");
            String date1=sin.next();
            LocalDate startDate=LocalDate.parse(date1);
            System.out.print("Please enter end date (yyyy-MM-dd) : ");
            String date2=sin.next();
            LocalDate endDate=LocalDate.parse(date2);
            System.out.print("Please Enter First State code : ");
            String firstStateCode = sin.next().toUpperCase();
            System.out.print("Please Enter Second State code : ");
            String secondStateCode = sin.next().toUpperCase();
            System.out.println("DATE       |      FIRST STATE     |     FIRST STATE CONFIRMED TOTAL     |     SECOND STATE     |    SECOND STATE CONFIRMED TOTAL	");
            for (ConcurrentMap.Entry<LocalDate,ConcurrentMap<String,Integer>> mapEntry :(service.getConfirmedCasesByComparingTwoStatesData(startDate,endDate,firstStateCode,secondStateCode)).entrySet()) {
                System.out.println(mapEntry.getKey() + " |          " + firstStateCode + "          |                 " + mapEntry.getValue().get(firstStateCode) + "                 |          " + secondStateCode + "          |               " + mapEntry.getValue().get(secondStateCode));
            }
        }

    }
