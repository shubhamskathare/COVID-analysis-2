package com.mindtree;

import com.mindtree.Dao.DataBaseConnectionDao;
import com.mindtree.Exceptions.InvalidDateException;
import com.mindtree.Exceptions.InvalidDateRangeException;
import com.mindtree.Exceptions.InvalidStateCodeException;
import com.mindtree.Exceptions.NoDataFoundException;
import com.mindtree.Service.CovidDataServiceForTests;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;

import static org.junit.jupiter.api.Assertions.*;

public class CovidDataServiceTest {
    private static CovidDataServiceForTests covidDataServiceForTests;
    public CovidDataServiceTest() throws SQLException, ClassNotFoundException {
        covidDataServiceForTests = new CovidDataServiceForTests(new DataBaseConnectionDao());
    }

    @Test
    @DisplayName("Testing all states present or not")
    @Tag("getAllUniqueStatesTestTag")
    public void getAllUniqueStatesTest() {
        assertEquals(covidDataServiceForTests.getAllUniqueStates().size(), 35);
        assertTrue(covidDataServiceForTests.getAllUniqueStates().containsAll(Set.of("AN", "AP", "AR", "AS", "BR", "CH", "CT", "DL", "DN", "GA","GJ","HP","HR","JH","JK","KA","KL","LA","MH","ML","MN","MP","MZ","NL","OR","PB","PY","RJ","SK","TG","TN","TR","UP","UT","WB")));
    }

    @Test
    @DisplayName("Testing whether the districts are present in the valid state code")
    @Tag("getAllUniqueDistrictsUnderSpecificStateCodeTestTag")
    public  void getAllUniqueDistrictsUnderSpecificStateCodeTest() throws InvalidStateCodeException {
        List<String> districtNamesUnderAState = covidDataServiceForTests.getAllUniqueDistrictsUnderSpecificStateCode("CH");
        assertTrue(districtNamesUnderAState.containsAll(Arrays.asList("Chandigarh", "Samba")));
        }

    @Test
    @DisplayName("Testing whether state code is valid or not")
    @Tag("invalidStateCodeTestTag")
    public  void invalidStateCodeTest() {
        InvalidStateCodeException assertThrows = assertThrows(InvalidStateCodeException.class, () -> covidDataServiceForTests.getAllUniqueDistrictsUnderSpecificStateCode("aa"));
        assertEquals("Invalid State code,please check your input.", assertThrows.getMessage());
    }

    @Test
    @DisplayName("Testing the getStatesDataWithInDateRange is empty or not")
    @Tag("getStatesDataWithInDateRangeTestTag")
    public void getStatesDataWithInDateRangeTest() throws InvalidDateException, InvalidDateRangeException, NoDataFoundException {
        ConcurrentMap<LocalDate, ConcurrentMap<String,Integer>> datesRange=covidDataServiceForTests.getStatesDataWithInDateRange(LocalDate.of(2020,Month.MARCH,22),LocalDate.of(2020,Month.AUGUST,7));
        assertFalse(datesRange.isEmpty());
    }

    @Test
    @DisplayName("Testing state code present in between dates range")
    @Tag("invalidStateCodeDateRangeTestTag")
    public void invalidStateCodeDateRangeTest() {
        InvalidStateCodeException assertThrows = assertThrows(InvalidStateCodeException.class, () -> covidDataServiceForTests.getConfirmedCasesByComparingTwoStatesData(LocalDate.of(2020, 3, 22), LocalDate.of(2020, 3, 23), "T", "C"));
        assertEquals("Invalid State code, please check your input", assertThrows.getMessage());
    }

    @Test
    @DisplayName("Testing given date is invalid throw InvalidDateException")
    @Tag("confirmedCasesInvalidDateTestTag")
    public void confirmedCasesInvalidDateTest() {
        assertThrows(InvalidDateException.class, () -> covidDataServiceForTests.getStatesDataWithInDateRange(LocalDate.of(2019, Month.AUGUST, 1), LocalDate.of(2022, Month.JUNE, 1)));
    }

    @Test
    @DisplayName("Testing given date range is invalid throw InvalidDateRangeException")
    @Tag("confirmedCasesInvalidDateRangeTestTag")
    public void confirmedCasesInvalidDateRangeTest() {
        assertThrows(InvalidDateRangeException.class, () -> covidDataServiceForTests.getStatesDataWithInDateRange(LocalDate.of(2020, Month.MARCH, 22), LocalDate.of(2020, Month.MARCH, 22)));
    }

    @Test
    @DisplayName("Testing getConfirmedCasesByComparingTwoStatesData is empty or not")
    @Tag("getConfirmedCasesByComparingTwoStatesDataTag")
    public void getConfirmedCasesByComparingTwoStatesDataTest() throws InvalidDateException, InvalidDateRangeException, NoDataFoundException, InvalidStateCodeException {
        ConcurrentMap<LocalDate, ConcurrentMap<String,Integer>> datesRange=covidDataServiceForTests.getConfirmedCasesByComparingTwoStatesData(LocalDate.of(2020,Month.MARCH,22),LocalDate.of(2020,Month.AUGUST,7),"TG","CH");
        assertFalse(datesRange.isEmpty());
    }


    @Test
    @DisplayName("Testing confirmed Cases between Two States and throwing InvalidDateRangeException")
    @Tag("confirmedCasesTwoStatesTestTag")
    public void confirmedCasesTwoStatesInvalidTest() {
        assertThrows(InvalidDateRangeException.class, () -> covidDataServiceForTests.getConfirmedCasesByComparingTwoStatesData(LocalDate.of(2020, 3,22), LocalDate.of(2020, 3, 22), "PB", "CH"));
    }

    @Test
    @DisplayName("Testing confirmed Cases between Two States and throwing  NoDataFoundException")
    @Tag("confirmedCasesTwoStatesNoDataTestTag")
    public void confirmedCasesTwoStatesNoDataTest() {
        assertThrows(InvalidDateRangeException.class, () -> covidDataServiceForTests.getConfirmedCasesByComparingTwoStatesData(LocalDate.of(2020, 3, 22), LocalDate.of(2020, 3, 22), "TG", "CH"));
    }


    @Test
    @DisplayName("Testing given dates are invalid for confirmed Cases between Two States throw InvalidDateException")
    @Tag("confirmedCasesTwoStatesInvalidDateTestTag")
    public void confirmedCasesTwoStatesInvalidDateTest() {
        assertThrows(InvalidDateException.class, () -> covidDataServiceForTests.getConfirmedCasesByComparingTwoStatesData(LocalDate.of(2019, 8, 4), LocalDate.of(2020, 8, 7), "PB", "CH"));
    }


}
